import requests
import bs4
import webbrowser

def 구글검색(키워드) :
    검색url양식 = "https://www.google.co.kr/search?q={0}"
    응답 = requests.get(검색url양식.format(키워드))

    
    #뷰티풀 숩
    스프 = bs4.BeautifulSoup(응답.text, 'html.parser')
    #검색 결과 링크 선택
    결과링크 = 스프.select('.r a')
    for 링크 in 결과링크[:5] :
        url = 링크.get('href')
        #웹브라우저에서 링크 열기
        webbrowser.open('http://google.com'+url)
    


구글검색('칼퇴근')
    
