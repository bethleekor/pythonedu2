import requests

response = requests.get('http://www.example.com')
html = response.text

snapshotfile = open('exaple_com.html', 'w', encoding='utf-8')
snapshotfile.write(html)
snapshotfile.close()


