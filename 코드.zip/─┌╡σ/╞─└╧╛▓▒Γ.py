import os
from random import sample

로또비책 = open('로또비책.txt', 'w')

#write는 덮어씀
#close하면서 write는 한번에 기록함
점지해주신번호 = '1 2 3 4 5 6'
로또비책.write(점지해주신번호)

로또비책.close()


로또비책 = open('로또비책.txt', 'a')

점지해주신번호 = '2 3 4 5 6 7'
로또비책.write('\n')
로또비책.write(점지해주신번호)
로또비책.close()


로또비책 = open('로도비책.txt')
로또번호 = 로또비책.read()
print(로또번호)
