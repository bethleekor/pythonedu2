import shutil
import os
from send2trash import send2trash

#shutil.copy('README.txt', '..')
#shutil.copy('README.txt', '../안내.txt')
#shutil.copy('기획', '..')

#shutil.copytree('기획', '../백업/기획')

#파일 확장자 없이 생성
#shutil.move('박명수.txt', '../업무')

#파일 삭제
#os.unlink('../업무')
#폴더 삭제 - 파일 있으면 안됨
#os.removedir('../백업')

os.makedirs('빈폴더')
os.rmdir('빈폴더')

#하위 폴더 다 찾아서 지워줌
#바로 삭제되서 복구할 수 없음!
#휴지통으로 들어가게 처
#shutil.rmtree('../백업')
#send2trash('../안내.txt')
send2trash('../test')
