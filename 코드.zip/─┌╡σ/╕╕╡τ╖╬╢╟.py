from random import sample

만든로또 = open('만든로또.txt', 'w')

def 로또번호생성() :
    로또번호 = sample(range(1, 46), 6) #.sort()
    로또번호.sort()
    return 로또번호
    
#write의 대상은 문자임!

for 주간 in range(100) :
    로또번호 = 로또번호생성()
    
    #만든로또.write(str(로또번호))
    내용 = ', '.join(map(str, 로또번호))
    만든로또.write(내용)
    만든로또.write('\n')
    #print(로또번호)

만든로또.close()

만든로또 = open('만든로또.txt', 'r')
만든결과 = 만든로또.read()
print(만든결과)

만든로또.close()
