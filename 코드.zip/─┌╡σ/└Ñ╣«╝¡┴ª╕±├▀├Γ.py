from urllib import request


def 태크추출(시작태그, 끝태그):
    시작 = 본문.find(시작태그)
    종료 = 본문.find(끝태그) + len(끝태그)
    태그 = 본문[시작:종료]
    return 태그



#TODO 원하는 만큼 주소 입력하기

주소목록 = []

while 1:
    대상URL = input('URL 입력: ')
    if 대상URL == '' :
        break
    else:
        if 'http://' in 대상URL :
            주소목록.append(대상URL)
        else:
            주소목록.append('http://'+대상URL)

print(주소목록)    

for 주소 in 주소목록:
    #웹 문서를 가져옴
    웹문서 = request.urlopen(주소)

    #본문을 읽음
    #본문 = 웹문서.read().decode('utf-8')
    본문 = 웹문서.read().decode('utf-8')

    # 제목추출
    제목시작 = 본문.find('<title>')
    제목종료 = 본문.find('</title>') + len('</title>')

    제목 = 본문[제목시작:제목종료]

    print(제목)

    # 제목1 내용 추출
    시작 = 본문.find('<h1>')
    종료 = 본문.find('</h1>') + len('</h1>')
    제목1 = 본문[시작:종료]

    print(제목1)



    
