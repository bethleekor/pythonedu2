# coding: utf-8
튜링파일 = open('D:/jin/코드/앨런튜링_utf8.txt', encoding='utf-8')
내용 = 튜링파일.read()
print(내용)

튜링파일.close()
