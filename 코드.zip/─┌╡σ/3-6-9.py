#3-6-9 게임
#3,6,9에서 짝!

숫자 = 1
while 숫자 < 20 :
    숫자 = 숫자+1
    
    if ('3' in str(숫자)) or ('6' in str(숫자)) or ('9' in str(숫자)):
        print('짝!')
    else:
        print(숫자)


