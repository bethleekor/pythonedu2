import os

def generateReadme(path, partname) :
    readme = open(path, 'w', encoding="utf-8")
    readme.write("NCSOFT 2016")
    readme.write("\n")
    readme.write("업무자동화를 위해 생성된 파일 입니다.")
    readme.write("\n")
    readme.write("{0},{1}".format("이진", "jin2"))
    #TODO: 각 부서별 안내 삽입
    readme.write("\n")
    readme.write("{0} 부서용".format(partname))
    readme.close()


#1. 기획, 개발, 아트, 교육 폴더 생성
partlist = ['기획', '개발', '아트']
for partname in partlist :
    #1. 해당 부서 폴더 생성
    if (not os.path.exists(partname)) :
        os.makedirs(partname)

    #2. 각 부서별 폴더의 경로 획득
    readmepath = os.path.join(partname, 'README.txt')

    #3. 각 부서별 폴더 내 readme 생성
    generateReadme(readmepath, partname)
