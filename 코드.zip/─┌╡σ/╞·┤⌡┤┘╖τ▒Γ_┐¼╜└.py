import os

print(os.getcwd())

for year in range(2010, 2017) :
    for month in range(1, 13) :
        month = '{:02d}'.format(month)
        
        path = os.path.join(str(year), month)

        os.makedirs(path)
        
