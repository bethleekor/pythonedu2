import os

os.chdir('C:/Users/엔씨/업무/자동화')
os.getcwd()

#os.makedirs('데이터/2016')
#os.listdir()

#os.chdir('데이터/2016')
#os.getcwd()

#################
for year in range(2010, 2017) :
    for month in range(1,13) :
        
        #using format
        month = '{:02d}'.format(month)

        path = os.path.join('데이터', str(year), month)

        if (not os.path.exists(path)) :
            os.makedirs(path)
'''
#ver2   
for year in range(2010, 2017) :
    for month in range(1,13) :
        month = str(month)
        
        if (len(month) < 2) :
            month = "0"+month

        path = os.path.join('데이터', str(year), month)

        if (not os.path.exists(path)) :
            os.makedirs(path)

'''
#################
'''
#ver1
for idx in range(0, 12) :
    month = str(idx+1)
    print(len(month))

    if len(month) < 2 :
        month = "0"+month
    if os.path.exists(month) :
        continue
    else :
        os.makedirs(month)



os.chdir('../')
for idx in range(2010, 2015) :
    year = str(idx+1)
    
    if os.path.exists(year) :
        continue
    else :
        os.makedirs(year)

'''
