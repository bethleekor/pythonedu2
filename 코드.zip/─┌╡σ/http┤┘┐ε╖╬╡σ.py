import requests, bs4

def httpdownload(url) :
    #http get 요청
    response = requests.get(url)

    if (response.status_code == 200) :
        print(response.encoding)
        return response
      
    else :
        print('응답코드 {0}, 뭔가 잘못됨'.format(response.status_code))
        return #더이상 할 것이 없으니 종료        

def filesave(file, filename) :
    snapshotfile = open(filename, 'w', encoding='utf-8')
    snapshotfile.write(file)
    snapshotfile.close()    

응답 = httpdownload('http://www.naver.com')
응답 = httpdownload('http://biz.khan.co.kr')
#filesave(응답.text, 'naver_home')
스프 = bs4.BeautifulSoup(응답.text, 'html.parser')
print(스프.title)
#문서내 모든 링크 태그 추출
print(스프.select('a'))
