import zipfile
'''
codeZip = zipfile.ZipFile('../코드.zip')
print(codeZip.namelist())
codeZip.close()

codeZip = zipfile.ZipFile('../코드.zip')
codeZip.extractall()
codeZip.close()
'''

'''
codeZip = zipfile.ZipFile('../개발.zip', 'w', compression=zipfile.ZIP_DEFLATED)
codeZip.write('README1.txt')
codeZip.write('README2.txt')
codeZip.close()
'''

codeZip = zipfile.ZipFile('../테스트.zip', 'w', compression=zipfile.ZIP_DEFLATED)
codeZip.write('../README1.txt', 'README1.txt')
codeZip.write('../README2.txt', 'README2.txt')
codeZip.close()
