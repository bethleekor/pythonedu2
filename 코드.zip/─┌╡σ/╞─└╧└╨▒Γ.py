import os

#print(os.getcwd())

튜링파일 = open('앨런튜링.txt')
#내용 = 튜링파일.read()

#리스트에 한줄씩! 
#각줄 = 튜링파일.readlines()
각줄 = 1
각줄 = 튜링파일.readlines()

#커서의 위치 확인
print(튜링파일.tell())
print(os.path.getsize('앨런튜링.txt'))


튜링파일.seek(0)
각줄 = 튜링파일.readlines()
튜링파일.close()

마지막줄 = 각줄[-1]
print(마지막줄)
