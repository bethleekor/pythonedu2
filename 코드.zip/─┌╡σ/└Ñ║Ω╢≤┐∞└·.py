import webbrowser

#readlines해야지 list 형태로 옴!

website = open('웹사이트목록.txt', 'r', encoding='utf-8')
weblist = website.readlines()

for url in weblist :
    #앞 뒤에 있을 수 있는 줄바꿈 문자 제거
    webbrowser.open(url.strip('\n'))

